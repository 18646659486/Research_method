# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class csat_customer(OntologyObject):
    """客户"""

    def __init__(self) -> None:
        self._table_name = "csat_customer"
        self._field_map = {
            "ITV数": "cust_itv_cnt",
            "视频彩铃数": "cust_spcl_cnt",
            "宽带数": "cust_brd_cnt",
            "来电名片数": "cust_ldmp_cnt",
            "用户年龄": "cust_age",
            "客户名称": "cust_name",
            "天翼卡数": "cust_mbl_cnt",
            "客户战略分群": "cust_type",
            "新装固话数": "cust_new_fix_cnt",
            "固话数": "cust_fix_cnt",
            "新装天翼卡数": "cust_new_mbl_cnt",
            "新装宽带数": "cust_new_brd_cnt",
            "新装ITV数": "cust_new_itv_cnt",
            "客户标识": "cust_id",
        }
        self._primary_key_attr = "客户标识"
