# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class Plan(OntologyObject):
    """建议方案"""

    def __init__(self) -> None:
        self._table_name = "CSAT_PLANS"
        self._field_map = {
            "产品实例ID": "PROD_INST_ID",
            "ID": "ID",
            "引用策略ids": "USED_STRA_IDS",
            "客户ID": "CUST_ID",
            "建议方案内容": "CONTENT",
        }
        self._primary_key_attr = "ID"
