# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class Customer_Satisfaction(OntologyObject):
    """客户使用满意度画像"""

    def __init__(self) -> None:
        self._table_name = "CSAT_USER_SATISFACTION"
        self._field_map = {
            "语音时长": "CALL_DUR_TOTAL",
            "客户标识": "CUST_ID",
            "本月RSRP小于负115的MR总数目": "RSRP_LT_115",
            "是否零次户": "ZERO_USER_FLAG",
            "本月访问主流网站的网页显示成功率百分比": "KQI_HTTPWEBCMPLTRATE_TOPWEBSITE",
            "本月不满意来话次数": "DISSATISFY_CNT",
            "本月RSRP优良率": "RSRP_RTO_115",
            "本月网页响应成功率百分比": "KQI_HTTPWEBRSPRATE",
            "本月网页显示成功率百分比": "KQI_HTTPWEBCMPLTRATE",
            "客户星级": "STAR_LEVEL",
            "短信条数": "MBL_SP_MMS_RECV_CNT",
            "用户年龄": "CUST_AGE",
            "本月访问主流网站的网页响应成功率百分比": "KQI_HTTPWEBRSPRATE_TOPWEBSITE",
            "本月投诉次数": "TS_MONTH_CNT",
            "性别": "GENDER",
            "本月RSRP大于等于负115的MR总数目": "RSRP_GE_115",
            "本月故障申告次数": "FAULT_CNT",
            "是否活跃用户": "ACTIVE_USER_FLAG",
            "本月重复报障次数": "REPEAT_FAULT_CNT",
            "本月最小RSRP优良率百分比": "RSRP_MIN_RTO_115",
            "本月网页异常话单总次数": "SUM_TIMES_AB_HTTP",
            "被叫次数": "CALLED_CNT",
            "本月最小网页响应成功率百分比": "MIN_KQI_HTTPWEBRSPRATE",
            "手机号": "MSISDN",
            "本月RSRP优良率低于百分之80的天数": "RSRP_RTO_115_LT_80_CNT",
            "本月最小网页显示成功率百分比": "MIN_KQI_HTTPWEBCMPLTRATE",
            "被叫时长": "CALLED_DUR",
            "网格_支局_编码": "SUB_GRID_ID",
            "网格_支局_名称": "SUB_GRID_NAME",
            "主叫次数": "CALLING_CNT",
            "产品实例标识": "PROD_INST_ID",
            "本月RSRP大于等于负105的MR总数目": "RSRP_GE_105",
            "手机上网时长": "MBL_INNET_DUR",
            "本月重复投诉次数": "REPEAT_COMPLAINT_CNT",
            "本月使用流量": "MBL_INNET_FLUX",
            "客户战略分群": "CUST_TYPE",
            "本月RSRP小于负105的MR总数目": "RSRP_LT_105",
        }
        self._primary_key_attr = "产品实例标识"
