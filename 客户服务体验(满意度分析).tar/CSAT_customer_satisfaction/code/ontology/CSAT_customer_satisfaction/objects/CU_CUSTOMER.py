# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class CU_CUSTOMER(OntologyObject):
    """test_客户"""

    def __init__(self) -> None:
        self._table_name = "CU_CUSTOMER"
        self._field_map = {
            "创建订单ID": "create_order_id",
            "参与方ID": "party_id",
            "客户标识": "cust_id",
            "操作日期": "op_date",
            "备注": "remark",
            "状态": "status",
            "业务类型代码": "busi_type_code",
            "销售ID": "sales_id",
            "状态日期": "status_date",
            "操作ID": "oprt_id",
            "销售角色类型": "sales_role_type",
            "操作序列号": "op_sn",
            "修改订单ID": "modify_order_id",
            "客户战略分群": "cust_type",
            "区域代码": "region_code",
            "创建操作ID": "create_oprt_id",
            "地址": "address",
            "创建机构ID": "create_org_id",
            "客户名称": "cust_name",
            "机构ID": "org_id",
            "创建日期": "create_date",
            "省份代码": "prov_code",
            "区县代码": "county_code",
            "客户简称": "cust_short_name",
            "客户等级": "cust_level",
        }
        self._primary_key_attr = "客户标识"
