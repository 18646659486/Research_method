# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class employee(OntologyObject):
    """员工"""

    def __init__(self) -> None:
        self._table_name = "employee"
        self._field_map = {
            "所属渠道ID": "channel_id",
            "员工联系电话": "phone_number",
            "员工状态": "employee_status",
            "员工唯一标识": "employee_id",
            "员工工号": "employee_number",
            "员工姓名": "employee_name",
            "创建时间": "created_time",
            "技能等级": "skill_level",
        }
        self._primary_key_attr = "员工唯一标识"
