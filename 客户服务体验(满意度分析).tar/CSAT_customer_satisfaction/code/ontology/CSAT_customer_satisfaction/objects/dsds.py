# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class dsds(OntologyObject):
    """dsdsd"""

    def __init__(self) -> None:
        self._table_name = "customer_valueaddedproduct_link"
        self._field_map = {
            "ID": "id",
            "客户ID": "customer_id",
            "产品ID": "product_id",
            "测试": "test",
        }
        self._primary_key_attr = "ID"
        self._pre_sql = None
