# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class Product(OntologyObject):
    """产品"""

    def __init__(self) -> None:
        self._table_name = "CSAT_WL_PRODUCT"
        self._field_map = {
            "客户标识": "cust_id",
            "手机号": "MSISDN",
            "产品实例标识": "PROD_INST_ID",
        }
        self._primary_key_attr = "产品实例标识"
