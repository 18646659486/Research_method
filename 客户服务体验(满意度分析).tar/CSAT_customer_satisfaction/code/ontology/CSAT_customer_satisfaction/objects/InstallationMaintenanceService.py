# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class InstallationMaintenanceService(OntologyObject):
    """装维服务"""

    def __init__(self) -> None:
        self._table_name = "service"
        self._field_map = {
            "服务名称": "service_name",
            "服务描述": "service_description",
            "服务唯一标识": "service_id",
            "所属渠道ID": "channel_id",
            "创建时间": "created_time",
            "服务类型": "service_type",
        }
        self._primary_key_attr = "服务唯一标识"
