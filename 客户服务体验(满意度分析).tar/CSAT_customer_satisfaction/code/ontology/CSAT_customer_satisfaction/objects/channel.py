# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class channel(OntologyObject):
    """部门"""

    def __init__(self) -> None:
        self._table_name = "channel"
        self._field_map = {
            "部门类型": "channel_type",
            "上级渠道ID": "parent_channel",
            "部门唯一标识": "channel_id",
            "创建时间": "created_time",
            "部门名称": "channel_name",
        }
        self._primary_key_attr = "部门唯一标识"
