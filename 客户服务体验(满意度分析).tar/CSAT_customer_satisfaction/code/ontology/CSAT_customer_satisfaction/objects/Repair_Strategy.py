# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class Repair_Strategy(OntologyObject):
    """修复策略"""

    def __init__(self) -> None:
        self._table_name = "CSAT_REPAIR_STRATEGY"
        self._field_map = {
            "特征": "feature",
            "策略唯一标识": "id",
            "主要问题": "main_issue",
            "解决方案": "strategy",
        }
        self._primary_key_attr = "策略唯一标识"
