# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class csat_test(OntologyObject):
    """测试对象"""

    def __init__(self) -> None:
        self._table_name = "csat_plans"
        self._field_map = {
            "ID": "id",
            "产品实例ID": "prod_inst_id",
            "内容": "content",
            "使用策略ID": "used_stra_ids",
            "客户ID": "cust_id",
        }
        self._primary_key_attr = "ID"
        self._pre_sql = None
