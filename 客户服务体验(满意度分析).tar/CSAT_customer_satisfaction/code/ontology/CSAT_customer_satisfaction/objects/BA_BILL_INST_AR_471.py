# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class BA_BILL_INST_AR_471(OntologyObject):
    """xfsdf"""

    def __init__(self) -> None:
        self._table_name = "BA_BILL_INST_AR_471"
        self._field_map = {
            "账单实例ID": "bill_inst_id",
            "账户ID": "acct_id",
            "用户ID": "subs_id",
            "服务号码": "service_number",
            "账单周期": "bill_cycle",
            "起始账单周期": "begin_bill_cycle",
            "结束账单周期": "end_bill_cycle",
            "账单项ID": "bill_item_id",
            "初始费用": "init_fee",
            "折扣费用": "discount_fee",
            "应收费用": "receivable_fee",
            "税率": "tax_rate",
            "税费": "tax_fee",
            "备注": "remark",
            "分拆项": "split_item",
            "项类型": "item_type",
            "费用团队ID": "fee_team_id",
            "操作日期": "op_date",
            "区域代码": "region_code",
            "服务商代码": "sp_code",
            "运营商代码": "operator_code",
            "产品ID": "product_id",
            "产品提供ID": "product_offering_id",
            "默认账户ID": "default_acct_id",
            "参考产品ID": "ref_product_id",
            "参考产品提供ID": "ref_product_offering_id",
        }
        self._primary_key_attr = "账单实例ID"
