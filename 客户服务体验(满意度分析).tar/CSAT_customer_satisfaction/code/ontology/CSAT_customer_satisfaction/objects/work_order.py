# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class work_order(OntologyObject):
    """工单"""

    def __init__(self) -> None:
        self._table_name = "work_order"
        self._field_map = {
            "负责员工ID": "employee_id",
            "工单详细内容": "workorder_content",
            "工单创建时间": "created_time",
            "工单完成时间": "completed_time",
            "工单标题": "workorder_title",
            "工单唯一标识": "workorder_id",
            "关联的建议方案ID": "plan_id",
            "客户反馈信息": "customer_feedback",
            "客户ID": "customer_id",
            "工单状态": "workorder_status",
            "产品实例ID": "product_inst_id",
            "创建工单的服务ID": "service_id",
            "优先级": "priority",
        }
        self._primary_key_attr = "工单唯一标识"
