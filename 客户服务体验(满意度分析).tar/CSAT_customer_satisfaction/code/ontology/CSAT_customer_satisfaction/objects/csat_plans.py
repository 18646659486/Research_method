# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class csat_plans(OntologyObject):
    """计划"""

    def __init__(self) -> None:
        self._table_name = "csat_plans"
        self._field_map = {
            "ID": "id",
            "内容": "content",
            "客户ID": "cust_id",
            "产品实例ID": "prod_inst_id",
            "已用策略ID": "used_stra_ids",
        }
        self._primary_key_attr = "ID"
