import setup
from core.runtime.registry import Function
from core.runtime.helpers import complex_sql

if __name__ == "__main__":
    result = complex_sql(
        ontology_name="CSAT_customer_satisfaction",
        sql="SELECT cust_name FROM csat_customer WHERE cust_age = %s",
        params=[46]
    )
    print(result)