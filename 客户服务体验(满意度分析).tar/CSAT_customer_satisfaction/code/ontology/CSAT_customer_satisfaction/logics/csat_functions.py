import setup
from core.runtime.registry import Function
from typing import Any, Dict
import requests

@Function
def get_prediction(prod_inst_ids: list):
    """
    调用满意度预测模型，获取满意度得分预测以及TOP3预测指标（技术指标）和技术指标所对应的业务指标。
    业务指标是根据业务经验映射得到的可量化指标，用于反映产品体验状态。预测模型返回的业务指标对应的客户产品使用满意度中相关的属性。
    需要根据属性的具体值，结合业务指标，来判断哪些issue_type是导致客户满意度低的潜在原因。支持批量预测。
    必须通过该函数来获取满意度得分信息。
    入参：
    prod_inst_ids -> 列表，包含需要进行预测的产品实例id
    """
    # from core.ontology.CSAT_customer_satisfaction.objects.Customer import Customer
    from core.ontology.CSAT_customer_satisfaction.objects.Product import Product

    api_url = "http://10.1.206.136:5333/api/v1/ontology/demo_api/predict"
    final_result = []
    try:
        for prod_inst_id in prod_inst_ids:
            response = requests.post(
                api_url,
                json={"prod_inst_id": prod_inst_id},
                headers={"Content-Type": "application/json"},
                timeout=300,
            )
            if response.status_code != 200:
                msg = f"HTTP {response.status_code}: {response.text}"
            
                return {"status": "error", "message": msg}

            result = response.json()
        
            if result.get("status") != "success":
                return {"status": "error", "message": result.get("message", "Unknown API error")}

            data = result.get("data", {})
            final_result.append(
                {
                "prod_inst_id": data.get("prod_inst_id"),
                "wlzl_score_pred": data.get("wlzl_score_pred"),
                "wlzl_score_TOP1": data.get("wlzl_score_TOP1"),
                "wlzl_score_TOP2": data.get("wlzl_score_TOP2"),
                "wlzl_score_TOP3": data.get("wlzl_score_TOP3"),
                "unconfirmed_metrics": data.get("unconfirmed_metrics"),
            }
            )
        return {
            "status": "success",
            "data": final_result
        }
    except requests.RequestException as e:
        msg = f"Network Error: Unable to connect to prediction API at {api_url}. Error: {str(e)}"
       
        return {"status": "error", "message": msg}
    except Exception as e:
        msg = f"Unexpected Error: {str(e)}"
     
        return {"status": "error", "message": msg}

@Function
def simulate_satisfaction_improvement(strategy_text: str):
    """
    Mock simulation logic to estimate satisfaction improvement for a given strategy.
    Returns a random value in [1.0, 3.0] with one decimal place.
    """
    from core.ontology.CSAT_customer_satisfaction.objects.Repair_Strategy import Repair_Strategy
    from core.ontology.CSAT_customer_satisfaction.objects.Customer_Satisfaction import Customer_Satisfaction
    
    import random
    return round(random.uniform(1.0, 3.0), 1)

@Function
def get_solution(issue_types: list[str]):
    """
    当判断出导致客户满意度低的issue_type为哪些后，调用该函数来为这些issue_type获取相应的修复策略
    """
    from core.ontology.CSAT_customer_satisfaction.objects.Repair_Strategy import Repair_Strategy

    api_url = "http://10.1.206.136:5333/api/v1/ontology/demo_api/get_solution"
    
    try:
        response = requests.post(
            api_url,
            json={"issue_type": issue_types},
            headers={"Content-Type": "application/json"},
            timeout=300,
        )
        if response.status_code != 200:
            msg = f"HTTP {response.status_code}: {response.text}"
            
            return {"status": "error", "message": msg}

        result = response.json()
        
        if result.get("status") != "success":
            return {"status": "error", "message": result.get("message", "Unknown API error")}

        data = result.get("data", [])
        
        return {"status": "success", "data": data}
    except requests.RequestException as e:
        msg = f"Network Error: Unable to connect to solution API at {api_url}. Error: {str(e)}"
        logger.error(msg)
        return {"status": "error", "message": msg}
    except Exception as e:
        msg = f"Unexpected Error: {str(e)}"
        logger.error(msg)
        return {"status": "error", "message": msg}

@Function
def is_low_satisfaction(scores: list):
    from core.ontology.CSAT_customer_satisfaction.objects.Customer_Satisfaction import Customer_Satisfaction
    result = []
    for score in scores:
        res = score < 6
        result.append(res)
    return result






