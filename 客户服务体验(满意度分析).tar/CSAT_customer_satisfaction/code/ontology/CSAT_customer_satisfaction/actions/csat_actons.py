from typing import Any

import setup
from core.ontology.CSAT_customer_satisfaction.objects.work_order import work_order
from core.ontology.CSAT_customer_satisfaction.objects.InstallationMaintenanceService import InstallationMaintenanceService
from core.ontology.CSAT_customer_satisfaction.objects.HotlineService import HotlineService
from core.ontology.CSAT_customer_satisfaction.objects.NetworkOptimizationService import NetworkOptimizationService
from core.runtime.registry import Action
from core.ontology.CSAT_customer_satisfaction.objects.Plan import Plan
import random
import time
import redis
import json

def push_data_to_redis(queue_name: str = None,data: Any = None):
    """
    推送数据到redis缓存
    """
    if queue_name is None:
        pass
    else:
        r = redis.Redis(host='10.19.29.140', port=6380, db=0,password="redis123456aB",decode_responses=True)
        try:
            json_data = json.dumps(data,ensure_ascii=False)
            r.lpush(queue_name, json_data)
        except Exception as e:
            print(e)
        r.close()


@Action(bind_to="Plan")
def insert_new_plan(plan: Plan, content: str, cust_id: str, prod_inst_id: str, used_stra_ids: str,simulation_instance_id: str = "simulation_instance_id"):
    """
    @action_label: 新增建议方案
    将生成的建议方案进行保存
    """
    
    plan_id = random.randint(1000,9999)
    new_plan = {
        "ID": plan_id,
        "建议方案内容": content,
        "客户ID": cust_id,
        "产品实例ID": prod_inst_id,
        "引用策略ids": used_stra_ids,
    }
    created_rows = plan.create(new_plan)
    used_stra_num = int(used_stra_ids)
    data ={}
    if used_stra_num < 100:
        params = {
            "service_id":"str",
            "cust_id":"str",
            "prod_inst_id":"str",
            "issue_description":"str",
            "plan_id":plan_id
        }
        data ={
            "ontology_name": "CSAT_customer_satisfaction",
            "action_name": "create_network_optimize_order",
            "object_name": "NetworkOptimizationService",
            "params":params
        }
        push_data_to_redis(simulation_instance_id, data)
        params = {
            "cust_id":"str",
            "service_id":"str",
            "prod_inst_id":"str",
            "complaint_type":"str",
            "complaint_details":"str",
            "plan_id":plan_id
        }
        data = {
            "ontology_name": "CSAT_customer_satisfaction",
            "action_name": "create_hotlines_order",
            "object_name": "HotlineService",
            "params": params
        }
        push_data_to_redis(simulation_instance_id, data)
    else:
        params = {
            "service_id":"str",
            "cust_id":"str",
            "prod_inst_id":"str",
            "issue_description":"str",
            "plan_id":plan_id
        }

        data = {
            "ontology_name": "CSAT_customer_satisfaction",
            "action_name": "create_installation_order",
            "object_name": "InstallationMaintenanceService",
            "params": params
        }
        push_data_to_redis(simulation_instance_id, data)


    if created_rows >= 1:
        return f"success, plan id is {plan_id}"
    else:
        return "failed"


@Action(bind_to="NetworkOptimizationService")
def create_network_optimize_order(networkOptimizationService: NetworkOptimizationService, service_id:str, cust_id: str, prod_inst_id: str, issue_description: str, plan_id: str=None,simulation_instance_id: str = "simulation_instance_id"):
    """
    @action_label: 创建网优服务工单
    根据网络优化需求创建工单，主要处理信号覆盖、网络质量等问题
    """
    try:
        # 生成工单ID
        workorder_id = f"WO_NET_{int(time.time())}_{random.randint(1000,9999)}"
        
        # 创建工单数据
        workorder_data = {
            "工单唯一标识": workorder_id,
            "工单标题": f"网络优化工单-{prod_inst_id}",
            "工单详细内容": f"客户{cust_id}的网络优化需求：{issue_description}",
            "工单状态": "created",
            "优先级": "medium",
            "创建工单的服务ID": service_id,
            "客户ID": cust_id,
            "产品实例ID": prod_inst_id,
            "关联的建议方案ID": plan_id
        }
        
        # 创建工单
        work_order_service = work_order()
        created_rows = work_order_service.create(data=workorder_data)
        #分配工单
        params = {
            "workorder_id":workorder_id,
            "employee_id":"str"
        }
        data = {
            "ontology_name": "CSAT_customer_satisfaction",
            "action_name": "assign_order_to_employee",
            "object_name": "work_order",
            "params": params
        }
        push_data_to_redis(simulation_instance_id, data)

        if created_rows >= 1:

            return f"success-工单已创建:{workorder_id}-待指派员工"
        else:
            return "failed-工单创建失败"
            
    except Exception as e:
        return f"failed-创建网优工单时出错:{str(e)}"


@Action(bind_to="HotlineService")
def create_hotlines_order(hotlineService: HotlineService, cust_id: str, service_id:str, prod_inst_id: str, complaint_type: str, complaint_details: str, plan_id: str=None,simulation_instance_id: str = "simulation_instance_id"):
    """
    @action_label: 创建万号服务工单
    处理客户投诉、咨询等热线服务需求
    """
    try:
        # 生成工单ID
        workorder_id = f"WO_HOT_{int(time.time())}_{random.randint(1000,9999)}"
        priority_map = {
            "紧急投诉": "high",
            "一般投诉": "medium", 
            "咨询": "low"
        }
        priority = priority_map.get(complaint_type, "medium")
        # 创建工单数据 
        workorder_data = {
            "工单唯一标识": workorder_id,
            "工单标题": f"万号工单-{prod_inst_id}",
            "工单详细内容": f"{complaint_details}",
            "工单状态": "created",
            "优先级": priority,
            "创建工单的服务ID": service_id,
            "客户ID": cust_id,
            "产品实例ID": prod_inst_id,
            "关联的建议方案ID": plan_id
        }
        
        # 创建工单
        work_order_service = work_order()
        created_rows = work_order_service.create(data = workorder_data)

        # 分配工单
        params = {
            "workorder_id": workorder_id,
            "employee_id": "str"
        }
        data = {
            "ontology_name": "CSAT_customer_satisfaction",
            "action_name": "assign_order_to_employee",
            "object_name": "work_order",
            "params": params
        }
        push_data_to_redis(simulation_instance_id, data)

        if created_rows >= 1:
            
            return f"success-工单已创建:{workorder_id}, 待指派员工"
        else:
            return "failed-工单创建失败"
            
    except Exception as e:
        return f"failed-创建万号工单时出错:{str(e)}"


@Action(bind_to="InstallationMaintenanceService")
def create_installation_order(installationMaintenanceService: InstallationMaintenanceService, service_id:str, cust_id: str, prod_inst_id: str, issue_description: str, plan_id: str=None,simulation_instance_id: str= "simulation_instance_id"):
    """
    @action_label: 创建装维服务工单
    处理宽带安装、设备维护等装维服务
    """
    try:
        # 生成工单ID
        workorder_id = f"WO_INS_{int(time.time())}_{random.randint(1000,9999)}"
        
        # 创建工单数据
        workorder_data = {
            "工单唯一标识": workorder_id,
            "工单标题": f"装维服务工单-{prod_inst_id}",
            "工单详细内容": f"{issue_description}",
            "工单状态": "created",
            "优先级": "medium",
            "创建工单的服务ID": service_id,
            "客户ID": cust_id,
            "产品实例ID": prod_inst_id,
            "关联的建议方案ID": plan_id
        }
        
        # 创建工单
        work_order_service = work_order()
        created_rows = work_order.create(workorder_data)

        # 分配工单
        params = {
            "workorder_id": workorder_id,
            "employee_id": "str"
        }
        data = {
            "ontology_name": "CSAT_customer_satisfaction",
            "action_name": "assign_order_to_employee",
            "object_name": "work_order",
            "params": params
        }
        push_data_to_redis(simulation_instance_id, data)
        
        if created_rows >= 1:
            return f"success-工单已创建:{workorder_id}-待指派员工"
        else:
            return "failed-工单创建失败"
            
    except Exception as e:
        return f"failed-创建网优工单时出错:{str(e)}"


@Action(bind_to="work_order")
def assign_order_to_employee(work_order: work_order, workorder_id: str, employee_id: str, simulation_instance_id: str= "simulation_instance_id"):
    """
    @action_label: 分配工单
    分配工单给指定员工
    """
    try:
        # 更新工单分配信息
        update_data = {
            "负责员工ID": employee_id,
            "工单状态": "assigned"
        }
        work_order.update_by_pk(workorder_id, update_data)
        return f"success-工单{workorder_id}已分配给员工{employee_id}"
    except Exception as e:
        return f"failed-分配工单时出错:{str(e)}"

if __name__ == "__main__":
    print(create_network_optimize_order(networkOptimizationService=NetworkOptimizationService(), service_id="SVC005",cust_id="1889774561", prod_inst_id="1889774561",issue_description="客户手机号1889774561存在低满意度情况，主要问题：本月RSRP优良率(-105)低于80%的天数2天，本月RSRP<-105的MR总数目22个，信号波动大导致通话质差和网络中断问题。需要网络质量优化和信号覆盖改善。"))


@Action(bind_to="work_order", build_type="function")
def jasd(work_order: work_order):
    """
    @action_label: 啊实打实大
    """
    # 在此处编辑你的逻辑
    return "success"
