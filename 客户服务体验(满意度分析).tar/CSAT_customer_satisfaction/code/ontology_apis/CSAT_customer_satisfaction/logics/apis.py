import setup
from core.runtime.registry import Function

@Function
def asd():
    """
    @function_label: 阿萨大
    @api_name: cyf测试
    测试
    
    API: GET http://localhost
    Timeout: 30s
    """
    import requests
    import json
    
    # Prepare API request
    url = "http://localhost"
    headers = {}
    params = {}
    body = {}
    
    
    # Make API request
    try:
        response = requests.get(url, headers=headers, params=params, timeout=30)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        return {"error": f"API request failed: {str(e)}"}
    except Exception as e:
        return {"error": f"Unexpected error: {str(e)}"}
