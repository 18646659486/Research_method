import setup
from core.runtime.registry import Action
from core.ontology.zhongxin_jinjie.objects.result import result
from datetime import datetime

# import markdown

# def markdown_to_html(md_text: str) -> str:
#     html = markdown.markdown(md_text)
#     return html
# 获取当前时间


# 格式化输出当前时间
# print("当前时间：", now.strftime("%Y-%m-%d %H:%M:%S"))


@Action(bind_to="result", build_type="function")
def write_result(Result: result,cust_id:str,markdown_content:str):
    """
    @action_label: 写入分析结果
    传入分析结果的markdown的格式，进行写入操作。
    """
    # 在此处编辑你的逻辑
    now = datetime.now()
    current_time = now.strftime("%Y-%m-%d %H:%M:%S")
    new_data = {
        '客户编码': cust_id,
        "建议类型": "服务类型",
        "建议内容": markdown_content,
        "生成时间": current_time
    }
    result_service = result()
    created_result = result_service.create(data = new_data)
    return "success"

# if __name__ == "__main__":
#     write_result(Result=result(),cust_id="001",markdown_content='##hello ')