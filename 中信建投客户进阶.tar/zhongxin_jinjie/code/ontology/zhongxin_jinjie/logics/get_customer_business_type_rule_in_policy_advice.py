import setup
from core.runtime.registry import Function

@Function
def get_customer_business_type_rule_in_policy_advice():
    """
    @function_label: 确认策略建议中的客户业务类型，无需输入参数。
    确认策略建议中的客户业务类型
    """
    # 在此处编辑你的逻辑
    return "根据客户和客户业务对象中的属性综合判断，目前现有的客户业务类型有两种。第一种：可触达客群且未有效认证企微客户。第二种：有股票持仓且最近20日有交易客户且从未参与过股票投顾客户。"
