import setup
from core.runtime.registry import Function

@Function
def getCustomerValidParticipationRule():
    """
    @function_label: 判断客户有效参与业务是否不足，无需输入参数。
    """
    # 在此处编辑你的逻辑
    return '从客户信息表中读取客户首次有效参与业务总数分位排名，当其排名>=0.7时，则认为该客户有效参与业务不足，否则认为客户有效参与业务充足'
