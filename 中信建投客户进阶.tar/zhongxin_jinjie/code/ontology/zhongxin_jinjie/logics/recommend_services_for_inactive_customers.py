import setup
from core.runtime.registry import Function

@Function
def recommend_services_for_inactive_customers():
    """
    @function_label: 为有效参与业务不足的客户推荐业务规则，无需输入参数。
    """
    # 在此处编辑你的逻辑
    return "首先查看该客户所在客群的信息。然后为该客户推荐该客群下按照参与业务占比排名在前3的业务且当前客户未参与的业务。"
