# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class serv_times(OntologyObject):
    """客户服务次数"""

    def __init__(self) -> None:
        self._table_name = "customer_info"
        self._field_map = {
            "客户编码": "cust_id",
            "客户服务次数": "serv_times",
        }
        self._primary_key_attr = "客户编码"
        self._pre_sql = None
