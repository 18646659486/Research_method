# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class result(OntologyObject):
    """分析结果"""

    def __init__(self) -> None:
        self._table_name = "tmep_result"
        self._field_map = {
            "客户编码": "cust_id",
            "建议类型": "suggesstion",
            "建议内容": "suggesstion_info",
            "生成时间": "create_time",
        }
        self._primary_key_attr = "客户编码"
        self._pre_sql = None
