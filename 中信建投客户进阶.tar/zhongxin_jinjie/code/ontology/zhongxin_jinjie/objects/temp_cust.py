# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class temp_cust(OntologyObject):
    """客户"""

    def __init__(self) -> None:
        self._table_name = "customer_info"
        self._field_map = {
            "营业部绩效分组": "brch_achv_group",
            "开户日期": "open_date",
            "分公司编码": "mngbrh_id",
            "数据日期": "data_dt",
            "客户股票持仓金额": "hold_amt",
            "客户风险等级": "cust_risk_grad",
            "客户资产分段": "cust_asset_seg",
            "客户经理岗位": "staff_posi",
            "客户编码": "cust_id",
            "是否可触达客户": "is_can_reach_cust",
            "客户年龄分段": "cust_age_seg",
            "客户年龄": "cust_age",
            "分公司名称": "mngbrh_name",
            "营业部名称": "brch_name",
            "近20交易日累计交易金额": "last_20_trd_day_sum_trd_amt",
            "是否最近20日有股票交易的客户": "is_last_20_trd_day_trd",
            "客户经理编码": "cust_mgr_id",
            "分公司绩效分组": "mngbrh_achv_group",
            "客户经理司龄": "staff_entry_years",
            "客户投资品种偏好": "cust_invst_vari_pref",
            "客户首次有效参与业务总数分位排名": "first_valid_join_biz_qty_rank",
            "客户性质": "cust_prop",
            "客户经理年龄": "staff_age",
            "营业部编码": "brch_id",
            "客群唯一编码": "grp_uniq_id",
            "客户经理姓名": "cust_mgr_name",
            "是否线上开户": "is_onle_open",
            "客户姓名": "cust_fname",
        }
        self._primary_key_attr = "客户编码"
        self._pre_sql = None
