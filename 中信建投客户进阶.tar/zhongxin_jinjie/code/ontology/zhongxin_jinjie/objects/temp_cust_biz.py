# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class temp_cust_biz(OntologyObject):
    """客户业务"""

    def __init__(self) -> None:
        self._table_name = "customer_giz"
        self._field_map = {
            "是否首次有效参与基金投顾业务": "is_first_valid_join_fia_biz",
            "是否首次有效参与权益类产品公募业务": "is_first_valid_join_equi_cls_prd_pub_fund_biz",
            "是否首次有效参与证券投顾业务": "is_first_valid_join_secu_ia_biz",
            "是否首次有效开通资金管理业务": "is_first_valid_open_funds_mng_biz",
            "是否首次有效参与固定收益类_非高端固收业务": "is_first_valid_join_fix_incm_cls_no_prem_fix_incm_biz",
            "是否首次有效开通北交所或科创板业务": "is_first_valid_open_bjse_star_biz",
            "是否首次有效参与非货币类ETF交易业务": "is_first_valid_join_no_crrc_cls_etf_trd_biz",
            "是否首次有效开通合格投资者业务": "is_first_valid_open_qi_biz",
            "是否首次有效开通港股通或跨境理财通业务": "is_first_valid_open_ggt_cros_bodr_lct_biz",
            "是否首次有效认证服务号": "is_first_valid_auth_serv_no",
            "是否首次有效参与融资融券业务": "is_first_valid_join_rzrq_biz",
            "是否首次有效参与基金定投业务": "is_first_valid_join_fund_auto_invest_biz",
            "是否首次有效参与固定收益类高端固收业务": "is_first_valid_join_fix_incm_cls_prd_pub_fix_incm_biz",
            "是否首次有效参与股票交易业务": "is_first_valid_join_stock_trd_biz",
            "是否首次有效参与现金管理类业务": "is_first_valid_join_cash_mng_cls_biz",
            "是否首次有效参与权益类产品私募或定制业务": "is_first_valid_join_equi_cls_prd_prvt_cust_made_biz",
            "客户编码": "cust_id",
            "数据日期": "data_dt",
            "是否首次有效认证企业微信": "is_first_valid_auth_wecom",
        }
        self._primary_key_attr = "客户编码"
        self._pre_sql = None
