# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class custFirstValidBizCount(OntologyObject):
    """客户首次有效参与业务总数"""

    def __init__(self) -> None:
        self._table_name = "customer_info"
        self._field_map = {
            "客户首次有效参与业务总数": "first_valid_join_biz_qty",
            "客户编码": "cust_id",
        }
        self._primary_key_attr = "客户编码"
        self._pre_sql = None
