# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class temp_cust_grp(OntologyObject):
    """客群"""

    def __init__(self) -> None:
        self._table_name = "customer_group_stats"
        self._field_map = {
            "客群首次有效参与权益类产品私募或定制业务客户数占比": "join_equi_cls_prd_prvt_cust_made_biz_cust_qty_ratio",
            "客群首次有效参与固定收益类非高端固收业务客户数占比": "join_fix_incm_cls_no_prem_fix_incm_biz_cust_qty_ratio",
            "客群首次有效参与融资融券业务客户数占比": "join_secu_ia_biz_cust_qty_ratio",
            "客群首次有效开通北交所或科创板业务客户数占比": "open_bjse_star_biz_cust_qty_ratio",
            "客群首次有效开通合格投资者业务客户数占比": "open_qi_biz_cust_qty_ratio",
            "客群首次有效参与非货币类ETF交易业务客户数占比": "join_zrrq_biz_cust_qty_ratio",
            "数据日期": "data_dt",
            "客群首次有效参与权益类产品公募业务客户数占比": "join_equi_cls_prd_pub_fund_biz_cust_qty_ratio",
            "客群首次有效参与基金定投业务客户数占比": "join_fund_auto_invst_biz_cust_qty_ratio",
            "客群首次有效参与现金管理类业务客户数占比": "join_cash_mng_biz_cust_qty_ratio",
            "客群唯一编码": "grp_uniq_id",
            "客群总客户数": "total_cust_qty",
            "客群首次有效认证服务号客户数占比": "auth_serv_no_cust_qty_ratio",
            "客群客户平均首次有效参与业务数": "cust_avg_first_valid_join_biz_qty",
            "客群首次有效参与固定收益类高端固收业务客户数占比": "join_fix_incm_cls_prem_fix_incm_biz_cust_qty_ratio",
            "客群首次有效开通资金管理业务客户数占比": "open_funds_mng_biz_cust_qty_ratio",
            "客群首次有效参与基金投顾业务客户数占比": "join_fia_biz_cust_qty_ratio",
            "客群首次有效认证企业微信客户数占比": "auth_wecom_cust_qty_ratio",
            "客群首次有效开通港股通或跨境理财通业务客户数占比": "open_ggt_cross_bodr_lct_biz_cust_qty_ratio",
            "客群首次有效参与证券投顾业务客户数占比": "join_no_rrc_cls_etf_trd_biz_cust_qty_ratio",
            "客群名称": "grp_uniq_name",
        }
        self._primary_key_attr = "客群唯一编码"
        self._pre_sql = None
