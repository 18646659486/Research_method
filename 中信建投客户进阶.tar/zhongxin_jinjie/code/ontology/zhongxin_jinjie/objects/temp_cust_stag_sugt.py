# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class temp_cust_stag_sugt(OntologyObject):
    """策略建议"""

    def __init__(self) -> None:
        self._table_name = "customer_stag_sugt"
        self._field_map = {
            "客户业务类型": "cust_biz_type",
            "具体策略建议内容": "spec_stag_sugt_conte",
        }
        self._primary_key_attr = "客户业务类型"
        self._pre_sql = None
