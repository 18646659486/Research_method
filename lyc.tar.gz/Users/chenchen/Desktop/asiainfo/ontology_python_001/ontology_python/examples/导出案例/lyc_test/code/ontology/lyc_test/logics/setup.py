"""
路径设置模块 - 用于在logics目录作为工作空间时正确设置Python路径
在任何其他导入之前导入此模块
"""

import sys
import os

# 获取项目根目录（从当前文件向上3级）
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.abspath(os.path.join(current_dir, '../../../..'))

# 将项目根目录添加到Python路径的开头
if project_root not in sys.path:
    sys.path.insert(0, project_root)

