import setup
from typing import Any, Dict
from core.runtime.registry import Action
from core.ontology.lyc_test.objects.headteacher import headteacher

@Action(bind_to="headteacher", build_type="object")
def action1(headteacher: headteacher, data: Dict[str, Any]) -> int:
    """
    动作1
    [auto-generated action: create]

    Args:
        headteacher: headteacher instance
        data: Dict containing:
            - haedteacher2: (required)
            - headteacher1: (required)
    """
    return headteacher.create(data, ontology_name='lyc_test', object_type_name='headteacher')
