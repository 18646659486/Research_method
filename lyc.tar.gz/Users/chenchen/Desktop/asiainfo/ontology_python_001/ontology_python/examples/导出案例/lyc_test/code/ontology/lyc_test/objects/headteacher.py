# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class headteacher(OntologyObject):
    """校长"""

    def __init__(self) -> None:
        self._table_name = None
        self._field_map = None
        self._primary_key_attr = None
        self._pre_sql = None
