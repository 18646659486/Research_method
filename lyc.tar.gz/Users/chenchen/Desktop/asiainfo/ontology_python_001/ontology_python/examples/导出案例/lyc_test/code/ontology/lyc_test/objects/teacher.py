# Auto-generated Ontology class
# -*- coding: utf-8 -*-

from core.runtime.base import OntologyObject

class teacher(OntologyObject):
    """老师"""

    def __init__(self) -> None:
        self._table_name = "supplier"
        self._field_map = {
            "supplier_id": "supplier_id",
            "supplier_name": "supplier_name",
            "supplier_level": "supplier_level",
            "contact_info": "contact_info",
            "created_time": "created_time",
        }
        self._primary_key_attr = "supplier_name"
        self._pre_sql = None
